#include "ATarget.hpp"

int main(void)
{
    ATarget target;

    return 0;
}
