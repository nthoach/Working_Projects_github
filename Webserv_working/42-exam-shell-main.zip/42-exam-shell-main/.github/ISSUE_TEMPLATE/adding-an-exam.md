---
name: Adding an exam
about: Suggested the addition of an built-in exam
title: ''
labels: enhancement, exam
assignees: c-bertran

---

**What exam would you like to add?? Please describe.**
A clear and concise description of exam

**Additional context**
Add any other context or screenshots about the feature request here.
