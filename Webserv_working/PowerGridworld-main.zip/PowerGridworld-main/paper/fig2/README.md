This directory runs the experiment corresponding to Figure 2 in the paper.

