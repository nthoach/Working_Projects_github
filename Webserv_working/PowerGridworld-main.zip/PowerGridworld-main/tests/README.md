This directory uses PyTest:

```
pip install pytest
pytest .   
```

Tests are extremely minimal for now, checking basic imports, env creation and
stepping using baseline min/max/random policies.  There is no checking for
"physics" or "correctness"!
