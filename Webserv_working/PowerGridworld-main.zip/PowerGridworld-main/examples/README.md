# Examples of creating envs and running MARL training algorithms

